---
layout: post
title: Episode 1
image: /img/hello_world.jpeg
---

On the first official Episode of the 132 Breese Podcast the guys take a look at the Badger's games against Maryland and Michigan State.  How they watched the games.  Overview of the entire B1G Tourney, what was right what was wrong.  NFL combine talk. Time to talk NBA? Kobe's Oscar and Casey has some questions about  Twitter Bios. 

<iframe src="https://cast.rocks/player/11602/132-Breese-Podcast---Episode-1.mp3?episodeTitle=132%20Breese%20Podcast%20-%20Episode%201&podcastTitle=132%20Breese%20Podcast&episodeDate=March%205th%2C%202018&imageURL=https%3A%2F%2Fcast.rocks%2Fhosting%2F11602%2Ffeeds%2F6RG37.jpg&itunesLink=https%3A%2F%2Fitunes.apple.com%2Fus%2Fpodcast%2F132-breese-podcast%2Fid1353274149%3Fmt%3D2" style="border: ridge; min-height: 265px; max-height: 320px; max-width: 558px; min-width: 270px; width: 100%; height: 100%;" scrollbars="no"></iframe>
