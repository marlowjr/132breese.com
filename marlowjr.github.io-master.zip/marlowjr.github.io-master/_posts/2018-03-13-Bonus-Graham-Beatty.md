---
layout: post
title: Bonus
subtitle: Graham Beatty
tags: [Podcast, NCAA]
---

A great interview with former Harvard basketball star and our college basketball Ivy league insider Graham Beatty.  He goes over life playing in the Ivy League vs Power conferences, Ivy League championship game  ,thoughts on the NCAA, answers who had a better career him or Ben Brust and much much more. 

<iframe src="https://cast.rocks/player/11602/Bonus--Graham-Beatty-.mp3?episodeTitle=Bonus%3A%20Graham%20Beatty&podcastTitle=132%20Breese%20Podcast&episodeDate=March%2013th%2C%202018&imageURL=https%3A%2F%2Fcast.rocks%2Fhosting%2F11602%2Ffeeds%2F6RG37.jpg&itunesLink=https%3A%2F%2Fitunes.apple.com%2Fus%2Fpodcast%2F132-breese-podcast%2Fid1353274149%3Fmt%3D2" style="border: ridge; min-height: 265px; max-height: 320px; max-width: 558px; min-width: 270px; width: 100%; height: 100%;" scrollbars="no"></iframe>
