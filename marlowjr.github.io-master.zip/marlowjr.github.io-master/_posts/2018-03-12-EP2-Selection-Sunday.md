---
layout: post
title: Ep 2
subtitle: Selection Sunday
tag: [Podcast, NCAA]
---

Mega show! The guys break down all of Selection Sunday.  The new Selection show format, Bracket breakdown  & Predictions.  Also we have some NFL talk, Browns go crazy. Take a walk around campus, Casey's Corner Kick, and Golf is back (Tiger!!) 

<iframe src="https://cast.rocks/player/11602/Ep-2--Selection-Sunday.mp3?episodeTitle=Ep%202%3A%20Selection%20Sunday&podcastTitle=132%20Breese%20Podcast&episodeDate=March%2012th%2C%202018&imageURL=https%3A%2F%2Fcast.rocks%2Fhosting%2F11602%2Ffeeds%2F6RG37.jpg&itunesLink=https%3A%2F%2Fitunes.apple.com%2Fus%2Fpodcast%2F132-breese-podcast%2Fid1353274149%3Fmt%3D2" style="border: ridge; min-height: 265px; max-height: 320px; max-width: 558px; min-width: 270px; width: 100%; height: 100%;" scrollbars="no"></iframe>
